import os.path
import random
import sys

scenario=open('scenario.txt','r')
settingOff=open('setting off.txt','r')
encounter=open('encounter.txt','r')
largeroom=open('largeroom.txt','r')
kitchen=open('kitchen.txt','r')
bedroom=open('bedroom.txt','r')
gryla=open('gryla.txt','r')
win=open('win.txt','r')

print(scenario.read())
print(settingOff.read())
print(encounter.read())

while True:
    print ('You can enter(1) or flee(2).')
    try:
        inputPorch = int(input('What would you like to do?'))
    except:
        print('Your input must be an integer.')
        inputPorch = 0

    if inputPorch == 2:
        print ('Goodbye.')
        sys.exit()
        
    while inputPorch == 1:
            print (largeroom.read())
            print ('You can open the door on the left(1), door on the right(2), or search the messy table(3).')

            try:
                inputLargeroom = int(input('What would you like to do?'))
            except:
                print ('Your input must be an integer.')
                inputLargeroom = 0

            while inputLargeroom == 1:
                print (kitchen.read())
                print ('You can search the kitchen(1). Exit back to the large room(2). Or go downstairs(3)')
                try:
                    inputKitchen = int(input('What would you like to do?'))
                except:
                    print('Your input must be an integer.')
                    inputKitchen = 0

                if inputKitchen == 1:
                    print ('You did not find anything useful in the kitchen...')

                if inputKitchen == 2:
                    break

                while inputKitchen == 3:
                    print (gryla.read())
                                      
                    try:
                        inputRoll = int(input('What would you like to do?'))
                    except:
                        print ('Your input must be an integer.')
                        inputRoll = 0
                        
                    diceSides = 20
                        
                    if inputRoll == 1:
                        
                        for rolls in range (inputRoll):
                            userRolls = random.randrange(diceSides)+1
                            print ('Your roll is:', userRolls)
                            
                            if userRolls >= 12:
                                grylaRolls = random.randrange(diceSides)-4
                                print ('Grylas roll is:', grylaRolls)
                                userRolls = random.randrange(diceSides)+1
                                print ('Your roll is:', userRolls,'- You have defeated Gryla and have obtained the key to the chest!')
                                attackWin = int(input('Would you like to return to the bedroom(1)?'))

                                if attackWin == 1:
                                    print(win.read()) 
                                    sys.exit()
                                    
                    if inputRoll == 2:

                        for rolls in range (inputRoll):
                            userRolls = random.randrange(diceSides)+1
                            grylaRolls = random.randrange(diceSides)-4
                            print ('Your roll is:', userRolls)
                            print ('Grylas roll is:', grylaRolls)
                            break
                            
                        if userRolls >= grylaRolls:
                            print ('Gryla disappeared into the darkness...')
                            failAttack = int(input('Would you like to attack Gryla(1)? Or consider this encounter more carefully?(2)'))

                            if failAttack == 1:
                                
                               for rolls in range (inputRoll):
                                    userRolls = random.randrange(diceSides)+1
                                    print ('Your roll is:', userRolls)
                                    
                                    if userRolls >= 12:
                                        grylaRolls = random.randrange(diceSides)-4
                                        print ('Grylas roll is:', grylaRolls)
                                        userRolls = random.randrange(diceSides)+1
                                        print ('Your roll is:', userRolls,'- You have defeated Gryla and have obtained the key to the chest!')
                                        attackWin = int(input('Would you like to return to the bedroom(1)?'))

                                        if attackWin == 1:
                                            print(win.read()) 
                                            sys.exit()

                                    if userRolls <= 11:
                                        failPersuasion = int(input('It appears that you are limited in options. Would you like to consider this encounter more carefully?(1)?'))

                                        if failPersuasion == 1:

                                             for rolls in range (inputRoll):
                                                userRolls = random.randrange(diceSides)+1
                                                print ('Your roll is:', userRolls)
                                
                                                if userRolls >= 12:
                                                    grylaRolls = random.randrange(diceSides)-4
                                                    print ('Grylas roll is:', grylaRolls)
                                                    userRolls = random.randrange(diceSides)+1
                                                    print ('Your roll is:', userRolls,'- You have defeated Gryla and have obtained the key to the chest!')
                                                    attackWin = int(input('Would you like to return to the bedroom(1)?'))

                                                    if attackWin == 1:
                                                        print(win.read()) 
                                                        sys.exit()
                                                    
                                                if userRolls <=11:
                                                    print('Unfortunately you have lost the game...')
                                                    sys.exit()
                                                    
                            if userRolls <= grylaRolls:
                                break
                               
                            if failAttack == 2:

                                for rolls in range (inputRoll):
                                    userRolls = random.randrange(diceSides)+1
                                    print ('Your roll is:', userRolls)
                                    
                                    if userRolls >= 12:
                                        grylaRolls = random.randrange(diceSides)-4
                                        print ('Grylas roll is:', grylaRolls)
                                        userRolls = random.randrange(diceSides)+1
                                        print ('Your roll is:', userRolls,'- You have defeated Gryla and have obtained the key to the chest!')
                                        attackWin = int(input('Would you like to return to the bedroom(1)?'))

                                        if attackWin == 1:
                                            print(win.read()) 
                                            sys.exit()

                                    if userRolls <= 11:
                                        failPersuasion = int(input('It appears there are no more options to obtain the key. You have been defeated.'))
                                        sys.exit()
                                        
                    if inputRoll == 3:

                        for rolls in range (inputRoll):
                            userRolls = random.randrange(diceSides)+1
                            print ('Your roll is:', userRolls)
                            
                            if userRolls >= 12:
                                grylaRolls = random.randrange(diceSides)-4
                                print ('Grylas roll is:', grylaRolls)
                                userRolls = random.randrange(diceSides)+1
                                print ('Your roll is:', userRolls,'- You have defeated Gryla and have obtained the key to the chest!')
                                attackWin = int(input('Would you like to return to the bedroom(1)?'))

                                if attackWin == 1:
                                    print(win.read()) 
                                    sys.exit()
                                    
                            if userRolls <= 11:
                                failConsideration = int(input('It appears that you are limited in options. Would you like to attack(1)? Or flee(2)?'))

                                if failConsideration == 1:
                                    for rolls in range (inputRoll):
                                                userRolls = random.randrange(diceSides)+1
                                                print ('Your roll is:', userRolls)
                                
                                                if userRolls >= 12:
                                                    grylaRolls = random.randrange(diceSides)-4
                                                    print ('Grylas roll is:', grylaRolls)
                                                    userRolls = random.randrange(diceSides)+1
                                                    print ('Your roll is:', userRolls,'- You have defeated Gryla and have obtained the key to the chest!')
                                                    attackWin = int(input('Would you like to return to the bedroom(1)?'))

                                                    if attackWin == 1:
                                                        print(win.read()) 
                                                        sys.exit()
                                                    
                                                if userRolls <=11:
                                                    print('Unfortunately you have lost the game...')
                                                    sys.exit()
                                if failConsideration == 2:
                                    sys.exit()

            while inputLargeroom == 2:
                print(bedroom.read()) 
                print('You can search the bedroom (1), exit back into the large room(2), or open the chest(3).')

                try:
                    inputBedroom = int(input('What would you like to do?'))
                except:
                    print ('Your input must be an integer.')
                    inputRoll = 0

                if inputBedroom == 1:
                    print('You did not find anything in the bedroom...')

                if inputBedroom == 3:
                    print ('You need a key to unlock the chest...')

                if inputBedroom == 2:
                    break

            while inputLargeroom == 3:
                print ('You have found a dagger!')

                try:
                    inputDagger = int(input('Would you like to take this item?(1)')) 
                except:
                    print ('Your input must be an integer.')
                    inputDagger = 0

                if inputDagger == 1:
                    break
                    
                    

    
                    

                

            

    
